$(".menu ul li").hover(function () {
        // over
        $(this).children("ul").slideDown("slow");
        
    }, function () {
        // out
        $(this).children("ul").slideUp("fast");
    }
);